export const SecuritySection = () => {
  return <div></div>
}
